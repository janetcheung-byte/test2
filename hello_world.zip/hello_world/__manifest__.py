{
    'name': 'Hello World',
    'version': '1.0',
    'category': 'Tools',
    'summary': 'A simple static module that displays Hello World',
    'description': 'This module adds a menu item that displays "Hello World" on the main screen.',
    'author': 'Your Name',
    'depends': ['base'],
    'data': [
        'views/hello_world_view.xml',  # XML file reference
    ],
    'installable': True,
    'application': True,
}
